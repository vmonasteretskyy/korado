<?php include 'item.php'; ?>

<?php /*ini_set('display_errors', 1); */ ?>

<section class="cat-items">
	<h2>Акционные товары</h2>
	<div class="items-wrap">
	
		<?php echo $item1 ?>
		<?php echo $item1 ?>
		<?php echo $item1 ?>
		<?php echo $item1 ?>

	</div>
	<a class="btn transparent black" href="">Еще акции</a>
</section>

<section class="cat-items">
	<h2>Новинки</h2>
	<div class="items-wrap">
	
		<?php echo $item2 ?>
		<?php echo $item2 ?>
		<?php echo $item2 ?>
		<?php echo $item2 ?>

	</div>
	<a class="btn transparent black" href="">Еще новинки</a>
</section>

<section class="cat-items">
	<h2>Уцененный товар</h2>
	<div class="items-wrap">
	
		<?php echo $item3 ?>
		<?php echo $item3 ?>
		<?php echo $item3 ?>
		<?php echo $item3 ?>

	</div>
	<a class="btn transparent black" href="">Еще товар</a>
</section>