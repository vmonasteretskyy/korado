<div class="pg-wrap pg-wrap2">
	<div class="pg-row">
		<button type="button">предыдущая</button>
		<ul class="pg-ul">
			<li class="pg-li">1</li>
			<li class="pg-li">...</li>
			<li class="pg-li">3</li>
			<li class="pg-li active">4</li>
			<li class="pg-li">5</li>
			<li class="pg-li">...</li>
			<li class="pg-li">12</li>
		</ul>
		<button type="button">следующая</button>
	</div>
</div>