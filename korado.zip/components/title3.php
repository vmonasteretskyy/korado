<!-- calc - title -->
<section class="calc-title">
	<div class="wrap">
		<h2>Выбор радиатора</h2>
		<p>Мы предлагаем широкий ассортимент радиаторов на любой вкус. Убедитесь в этом!</p>
		<a class="btn black" href="">Смотреть все</a>
	</div>
</section>