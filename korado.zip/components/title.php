<section class="stitle">
	<div class="fixed-bg" style="background-image: url(<?php echo $titleimg; ?>);"></div>
	<div class="wrap">
		<h1><?php echo $title ?></h1>
		<p><?php echo $titledescr ?></p>
	</div>
</section>

<?php include 'breadcrumb.php'; ?>
