<?php include 'item.php'; ?>

<?php /*ini_set('display_errors', 1); */ ?>

<section class="cat-items">
	<h2>Акционные товары</h2>
	<div class="items-wrap">
	
		<?php echo $item1 ?>
		<?php echo $item2 ?>
		<?php echo $item3 ?>	
		<?php echo $item1 ?>

	</div>
	<a class="btn transparent black" href="">Еще акции</a>
</section>