<footer>
	<div id="footerhand" style="background-image: url(./assets/img/footer-hand.png);"></div>
	<div id="frow1">
		<p>Вы можете обратиться к нашим экспертам за помощью</p>
		<button type="button" class="btn transparent green">Заказать консультацию</button>
	</div>
	<div id="frow2">
		<span id="copyright">Copyright © KORADO-V. Все права защищены</span>
	</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/noUiSlider/14.6.0/nouislider.min.js"></script>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
<script src="./assets/scripts/neuscript.js"></script>
<script src="./assets/scripts/script.js"></script>
</body>
</html>