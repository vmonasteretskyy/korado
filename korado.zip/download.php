<?php include 'header.php'; ?>

<?php 
$titleimg = "./assets/img/category/info-bg.jpg";
$title = "Информация";
$titledescr = "О нас, о производителе <b>korado</b>, Каталоги"; 
?>

<?php include 'components/title2.php'; ?>

<section class="download-list">
	<div class="wrap">
		<div class="ditem icon-file">
			<span class="dtitle">Каталог продукции radik</span>
			<span class="dmem">462.83 КБ</span>
			<a class="icon-download"></a>
		</div>
		<div class="ditem icon-file">
			<span class="dtitle">Каталог продукции radik</span>
			<span class="dmem">462.83 КБ</span>
			<a class="icon-download"></a>
		</div>
		<div class="ditem icon-file">
			<span class="dtitle">Каталог продукции radik</span>
			<span class="dmem">462.83 КБ</span>
			<a class="icon-download"></a>
		</div>
		<div class="ditem icon-file">
			<span class="dtitle">Каталог продукции radik</span>
			<span class="dmem">462.83 КБ</span>
			<a class="icon-download"></a>
		</div>
		<div class="ditem icon-file">
			<span class="dtitle">Каталог продукции radik</span>
			<span class="dmem">462.83 КБ</span>
			<a class="icon-download"></a>
		</div>
		<div class="ditem icon-file">
			<span class="dtitle">Каталог продукции radik</span>
			<span class="dmem">462.83 КБ</span>
			<a class="icon-download"></a>
		</div>
		<div class="ditem icon-file">
			<span class="dtitle">Каталог продукции radik</span>
			<span class="dmem">462.83 КБ</span>
			<a class="icon-download"></a>
		</div>
		<div class="ditem icon-file">
			<span class="dtitle">Каталог продукции radik</span>
			<span class="dmem">462.83 КБ</span>
			<a class="icon-download"></a>
		</div>
		<div class="ditem icon-file">
			<span class="dtitle">Каталог продукции radik</span>
			<span class="dmem">462.83 КБ</span>
			<a class="icon-download"></a>
		</div>
		<div class="ditem icon-file">
			<span class="dtitle">Каталог продукции radik</span>
			<span class="dmem">462.83 КБ</span>
			<a class="icon-download"></a>
		</div>
		<div class="ditem icon-file">
			<span class="dtitle">Каталог продукции radik</span>
			<span class="dmem">462.83 КБ</span>
			<a class="icon-download"></a>
		</div>
		<div class="ditem icon-file">
			<span class="dtitle">Каталог продукции radik</span>
			<span class="dmem">462.83 КБ</span>
			<a class="icon-download"></a>
		</div>
	</div>
</section>

<?php include 'footer.php'; ?>