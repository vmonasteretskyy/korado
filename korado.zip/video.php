<?php include 'header.php'; ?>

<?php 
$titleimg = "./assets/img/category/gallery-bg.jpg";
$title = "Видео обзоры";
$titledescr = "Присмотритесь поближе узнайте больше о нашем продукте"; 
?>

<?php include './components/title.php'; ?>

<section class="ctlg-news">
	<div class="ctlg-swiper-wrap">
		<!-- Slider main container -->
		<div class="plates-ctlg">
			<!-- Additional required wrapper -->

			<div class="ctlg-n-el">
				<img class="ctlg-n-el-img" src="./assets/img/catalog/news/n1.jpg" alt="">
				<a class="ctlg-n-el-content icon-circleplay" data-fancybox href="https://www.youtube.com/watch?v=TnedWL2x6uk" data-caption="Актуальная информация о клиентах для коронавируса codiv-19">
					<h4>Актуальная информация о клиентах для коронавируса codiv-19</h4>
				</a>
			</div>

			<div class="ctlg-n-el">
				<img class="ctlg-n-el-img" src="./assets/img/catalog/news/n2.jpg" alt="">
				<a class="ctlg-n-el-content icon-circleplay" data-fancybox href="https://www.youtube.com/watch?v=TnedWL2x6uk" data-caption="New Radik VKM8 — решение для любого соединения">
					<h4>New Radik VKM8 — решение для любого соединения</h4>
				</a>
			</div>

<div class="ctlg-n-el">
	<img class="ctlg-n-el-img" src="./assets/img/catalog/news/n3.jpg" alt="">
	<a class="ctlg-n-el-content icon-circleplay" data-fancybox href="./assets/img/catalog/news/n3.jpg" data-caption="Обеспечить здоровье в вашем доме с надлежащим отоплением. Вы также избавитесь от вирусов.">
		<h4>Обеспечить здоровье в вашем доме с надлежащим отоплением. Вы также избавитесь от вирусов.</h4>
	</a>
</div>

<div class="ctlg-n-el">
	<img class="ctlg-n-el-img" src="./assets/img/catalog/news/n3.jpg" alt="">
	<a class="ctlg-n-el-content icon-circleplay" data-fancybox href="./assets/img/catalog/news/n3.jpg" data-caption="Обеспечить здоровье в вашем доме с надлежащим отоплением. Вы также избавитесь от вирусов.">
		<h4>Обеспечить здоровье в вашем доме с надлежащим отоплением. Вы также избавитесь от вирусов.</h4>
	</a>
</div>

<div class="ctlg-n-el">
	<img class="ctlg-n-el-img" src="./assets/img/catalog/news/n3.jpg" alt="">
	<a class="ctlg-n-el-content icon-circleplay" data-fancybox href="./assets/img/catalog/news/n3.jpg" data-caption="Обеспечить здоровье в вашем доме с надлежащим отоплением. Вы также избавитесь от вирусов.">
		<h4>Обеспечить здоровье в вашем доме с надлежащим отоплением. Вы также избавитесь от вирусов.</h4>
	</a>
</div>

<div class="ctlg-n-el">
	<img class="ctlg-n-el-img" src="./assets/img/catalog/news/n3.jpg" alt="">
	<a class="ctlg-n-el-content icon-circleplay" data-fancybox href="./assets/img/catalog/news/n3.jpg" data-caption="Обеспечить здоровье в вашем доме с надлежащим отоплением. Вы также избавитесь от вирусов.">
		<h4>Обеспечить здоровье в вашем доме с надлежащим отоплением. Вы также избавитесь от вирусов.</h4>
	</a>
</div>

<div class="ctlg-n-el">
	<img class="ctlg-n-el-img" src="./assets/img/catalog/news/n3.jpg" alt="">
	<a class="ctlg-n-el-content icon-circleplay" data-fancybox href="./assets/img/catalog/news/n3.jpg" data-caption="Обеспечить здоровье в вашем доме с надлежащим отоплением. Вы также избавитесь от вирусов.">
		<h4>Обеспечить здоровье в вашем доме с надлежащим отоплением. Вы также избавитесь от вирусов.</h4>
	</a>
</div>

<div class="ctlg-n-el">
	<img class="ctlg-n-el-img" src="./assets/img/catalog/news/n3.jpg" alt="">
	<a class="ctlg-n-el-content icon-circleplay" data-fancybox href="./assets/img/catalog/news/n3.jpg" data-caption="Обеспечить здоровье в вашем доме с надлежащим отоплением. Вы также избавитесь от вирусов.">
		<h4>Обеспечить здоровье в вашем доме с надлежащим отоплением. Вы также избавитесь от вирусов.</h4>
	</a>
</div>

<div class="ctlg-n-el">
	<img class="ctlg-n-el-img" src="./assets/img/catalog/news/n3.jpg" alt="">
	<a class="ctlg-n-el-content icon-circleplay" data-fancybox href="./assets/img/catalog/news/n3.jpg" data-caption="Обеспечить здоровье в вашем доме с надлежащим отоплением. Вы также избавитесь от вирусов.">
		<h4>Обеспечить здоровье в вашем доме с надлежащим отоплением. Вы также избавитесь от вирусов.</h4>
	</a>
</div>

<div class="ctlg-n-el">
	<img class="ctlg-n-el-img" src="./assets/img/catalog/news/n3.jpg" alt="">
	<a class="ctlg-n-el-content icon-circleplay" data-fancybox href="./assets/img/catalog/news/n3.jpg" data-caption="Обеспечить здоровье в вашем доме с надлежащим отоплением. Вы также избавитесь от вирусов.">
		<h4>Обеспечить здоровье в вашем доме с надлежащим отоплением. Вы также избавитесь от вирусов.</h4>
	</a>
</div>

		</div>
	</div>
	
</section>

<?php include './components/pagination2.php'; ?>

<?php include 'footer.php'; ?>